# GitHub Actions

The Android workflow is in `.github/workflows/android-build.yml`.

Optional repository secrets:
- `SUPABASE_URL`
- `SUPABASE_PUBLISHABLE_KEY`

The workflow builds `:app:assembleDebug` and uploads:
`Mr_x-debug.apk`
